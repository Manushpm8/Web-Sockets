Welcome to the our Submission of the Final Project: Graphical User Interface to Send Messages

This project was done by: Manush P Murali (14568752,mpmurali@uci.edu) & Shreyas V Chandramouli (70688884,svchand1@uci.edu).

This assignment includes the following starter files:

ds_protocol.py: used to convert messages into appropriate format accepted by the server
ds_messenger.py: contains the DirectMessage and DirectMessenger classes used by the program
Profile.py: contains the Profile and post (message) class used by the program
test_ds_messenger1.py: ds_messenger normal test
test_ds_messenger2.py: ds_messenger unittest
test_ds_message_protocol1.py: ds_protocol normal test
test_ds_message_protocol2.py: ds_protocol unittest
ui.py: entry point into the program
